# nrzl_LIB/__init__.py

from .NRZL_LIB import nrzl_encode, nrzl_decode, plot_nrzl
